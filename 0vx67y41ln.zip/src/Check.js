import React, { Component } from "react";
import "./Check.css";
class Check extends Component {
  constructor(props) {
    super();
  }
  render() {
    return (
      <div className="box">
        <input type="checkbox" />
        {this.props.label}
      </div>
    );
  }
}
export default Check;
