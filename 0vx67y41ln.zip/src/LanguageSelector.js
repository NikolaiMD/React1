import React, { Component } from "react";
import { render } from "react-dom";

class LangSelect extends Component {
  constructor() {
    super();
    this.lang = ["RO", "RU", "EN"];
  }
  render() {
    var langOpt = this.lang.map(lang => <option>{lang}</option>);
    return <select>{langOpt}</select>;
  }
}
export default LangSelect;
