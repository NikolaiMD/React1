// component module
import React, { Component } from "react";

class LikeButton extends Component {
  constructor(props) {
    // super to react
    super(props);
    // this.likes = 0;
    this.state = {
      likes: 0,
      enabled: true
    };
    this.click = this.click.bind(this);
  }
  click() {
    this.setState({
      likes: this.state.likes + 1
    });
    if (this.state.likes >= 2) {
      this.disable();
    }
    // alert(this.likes)
  }
  disable() {
    this.setState({
      enabled: false
    });
  }
  enable() {}
  render() {
    return (
      <button onClick={this.click} disabled={!this.state.enabled}>
        {this.props.label} {this.state.likes}
      </button>
    );
  }
}

export default LikeButton;
