import React from "react";
import ReactDOM from "react-dom";
import LikeButton from "./LikeButton";
import LangSelect from "./LanguageSelector";
import Check from "./Check.js";
import "./styles.css";

function App() {
  return (
    <div className="App">
      {/* <LikeButton label="I like this post" />
      <LikeButton label="I like this comment" />
      <LangSelect /> */}
      <Check label="I agree with this" />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
